package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import es.indra.models.Pedido;
import es.indra.models.Producto;

//El id del bean es el nombre de la clase pero la primera letra en minusculas
@Service("beanRestTemplate") // Hemos cambiado el id del bean
public class PedidosBSImplRestTemplate implements IPedidosBS{
	
	@Autowired
	private RestTemplate restTemplate;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		// Con el id buscamos el producto en el micro-servicio-productos
		Producto producto = restTemplate.getForObject(
				"http://localhost:8001/buscar/{codigo}", Producto.class, id);
		
		// Crear el pedido y retornarlo
		Pedido pedido = new Pedido(producto, cantidad);
		
		return pedido;
	}

}
