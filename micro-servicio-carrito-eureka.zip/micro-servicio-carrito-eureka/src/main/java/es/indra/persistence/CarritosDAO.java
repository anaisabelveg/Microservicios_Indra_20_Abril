package es.indra.persistence;

import org.springframework.data.mongodb.repository.MongoRepository;

import es.indra.models.Carrito;

// No necesitamos anotaciones, porque Spring Boot al heredar de xxxRepository lo
// detecta como un bean de Spring
public interface CarritosDAO extends MongoRepository<Carrito, String>{

	public Carrito findByUsuario(String usuario);
	
}
