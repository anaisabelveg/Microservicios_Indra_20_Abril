package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import es.indra.clients.PedidosClienteFeign;
import es.indra.models.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteFeign clienteFeign;

	@Override
	@Transactional(isolation = Isolation.SERIALIZABLE,
				   propagation = Propagation.REQUIRES_NEW,
				   rollbackFor = Exception.class)
	public Carrito crear(String usuario) {
		// Solo creamos el carrito si no existe otro para ese usuario
		Carrito carrito = consultar(usuario);
		
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		return carrito;
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		Pedido pedido = clienteFeign.crear(id, cantidad);
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		double importePedido = pedido.getProducto().getPrecio() * pedido.getCantidad();
		carrito.setImporte(importePedido + carrito.getImporte());
		return dao.save(carrito);
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		// Solo borro el primer pedido que encuentre con ese id de producto
		Pedido encontrado = contenido.stream()
								.filter(ped -> ped.getProducto().getID() == id)
								.findFirst()
								.get();
		
		contenido.remove(encontrado);
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		return dao.save(carrito);
	}

}
