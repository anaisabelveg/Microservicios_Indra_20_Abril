package es.indra.business;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import es.indra.clients.ProductosClienteFeign;
import es.indra.clients.ProveedoresClienteFeign;
import es.indra.models.Pedido;
import es.indra.models.Producto;

@Service
//@Primary // Damos preferencia a este bean en DI
public class PedidosBSImplFeign implements IPedidosBS{
	
	@Autowired
	private ProductosClienteFeign clienteFeign;
	
	@Autowired
	private ProveedoresClienteFeign proveedoresClienteFeign;

	@Override
	public Pedido crearPedido(Long id, int cantidad) {
		Producto producto = clienteFeign.buscar(id);
		Pedido pedido = new Pedido(producto, cantidad);
		return pedido;
	}

	@Override
	public String pruebaTransaccion(String descripcion, double precio, String nombre) {
		String mensaje = "";
		Producto producto = null;
		
		try {
			// Damos de alta el producto
			producto = clienteFeign.nuevo(descripcion, precio);
			
			// Damos de alta el proveedor
			proveedoresClienteFeign.altaProveedor(nombre);
			
			mensaje = "Todo ha ido bien, transacciones compleatadas";
		} catch (Exception e) {
			// Deshacer la transaccion, eliminamos el producto
			String msg = clienteFeign.eliminar(producto.getID());
			System.out.println("******* " + msg + " *******");
			
			mensaje = "Transaccion deshecha " + msg;
		}
		
		
		return mensaje;
	}

}
