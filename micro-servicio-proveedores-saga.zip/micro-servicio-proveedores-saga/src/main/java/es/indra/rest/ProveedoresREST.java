package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.IProveedoresBS;

@RestController
public class ProveedoresREST {
	
	@Autowired IProveedoresBS bs;
	
	@PostMapping("/alta/{nombre}")
	public String altaProveedor(@PathVariable String nombre) {
		return bs.crearProveedor(nombre);
	}

}
