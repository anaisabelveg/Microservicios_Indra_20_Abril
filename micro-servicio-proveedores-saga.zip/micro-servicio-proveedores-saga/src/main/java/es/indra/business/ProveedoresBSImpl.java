package es.indra.business;

import org.springframework.stereotype.Service;

@Service
public class ProveedoresBSImpl implements IProveedoresBS{

	@Override
	public String crearProveedor(String nombre) {
		
		if ("pepe".equals(nombre)) {
			throw new RuntimeException("Transaccion cancelada por nombre pepe");
		} else {
			return "Proveedor " + nombre + " creado con exito";
		}
		
	}

}
