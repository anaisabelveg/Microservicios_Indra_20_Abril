package es.indra.business;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.entities.Producto;
import es.indra.persistence.ProductosDAO;

/*
 * En Spring cualquier clase anotada con estas anotaciones, se reconoce como un bean de Spring
 * 		@Repository;  repositorios de datos, dao, erp, ...
 * 		@Controller;  controladores de Spring MVC
 * 		@Service;     logica de negocio, business, servicios, ...
 * 		@Component;   cuando la clase no es ninguna de las anteriores
 */

@Service
public class ProductosBSImpl implements IProductosBS{
	
	@Autowired   // Inyectar un bean de tipo ProductosDAO
	private ProductosDAO dao;  // DI

	@Override
	public List<Producto> consultarTodos() {
		return dao.findAll();
	}

	@Override
	public Producto buscarProducto(Long id) {
		return dao.findById(id).orElse(new Producto());
	}

	@Override
	public Producto crearProducto(Producto producto) {
		return dao.save(producto);
	}

	@Override
	public String eliminarProducto(Long id) {
		dao.deleteById(id);
		return "Producto eliminado " + id ;
	}

}
