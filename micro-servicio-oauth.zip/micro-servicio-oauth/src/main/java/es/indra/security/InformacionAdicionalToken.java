package es.indra.security;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.stereotype.Component;

import es.indra.business.IUsuariosBS;
import es.indra.models.Usuario;

@Component
public class InformacionAdicionalToken implements TokenEnhancer{
	
	@Autowired
	private IUsuariosBS bs;

	@Override
	public OAuth2AccessToken enhance(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
		// Este metodo es para completar la informacion del usuario que vemos en jwt.io
		
		Usuario usuario = bs.buscarUsuario(authentication.getName());
		
		Map<String, Object> informacion = new HashMap<>();
		informacion.put("nombre", usuario.getNombre());
		informacion.put("apellido", usuario.getApellido());
		informacion.put("email", usuario.getEmail());
		
		((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(informacion);
		
		return accessToken;
	}

}
