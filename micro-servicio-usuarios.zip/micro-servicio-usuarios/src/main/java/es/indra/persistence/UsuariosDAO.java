package es.indra.persistence;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.data.rest.core.annotation.RestResource;

import es.indra.entities.Usuario;

// Expongo el dao como un servicio REST
@RepositoryRestResource(path = "usuarios")
public interface UsuariosDAO extends JpaRepository<Usuario, Long>{
	
	// Consultar todos los usuarios
	// http://localhost:8006/usuarios
	
	// Todos los metodos personalizados
	// http://localhost:8006/usuarios/search
	
	// Puedo crear un metodo personalizado y exponerlo como operacion del servicio rest
	// http://localhost:8006/usuarios/search/buscar-username?username=juan
	@RestResource(path = "buscar-username")
	public Usuario findByUsername(@Param("username") String username);

}
