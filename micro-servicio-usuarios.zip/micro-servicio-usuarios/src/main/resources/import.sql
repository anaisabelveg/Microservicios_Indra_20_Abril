INSERT INTO usuarios(username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$qweYYH8WyV4epJs7InWKceCoDE.lYT.XX22Sm9bA4cavolw9vr3cy', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios(username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$TwM5Z5KLON7gXgWl3VQClu3ijFzFbMsR0wWQC5OOLvlWtA426mDrO', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles(nombre) values ('ROLE_USER');
INSERT INTO roles(nombre) values ('ROLE_ADMIN');

INSERT INTO usuarios_roles(usuario_id, role_id) values (1,1);
INSERT INTO usuarios_roles(usuario_id, role_id) values (2,1);
INSERT INTO usuarios_roles(usuario_id, role_id) values (2,2);