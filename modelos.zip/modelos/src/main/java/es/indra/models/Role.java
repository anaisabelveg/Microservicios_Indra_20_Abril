package es.indra.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data   // getter, setter, constructor completo, equals y hashcode, toString
//para que genere el constructor completo las propiedades tienen que ser final o anotadas con @NotNull
@NoArgsConstructor   // Constructor por defecto
public class Role {
	
	private Long id;
	private String nombre;
	
	public Role(String nombre) {
		super();
		this.nombre = nombre;
	}
	
}
