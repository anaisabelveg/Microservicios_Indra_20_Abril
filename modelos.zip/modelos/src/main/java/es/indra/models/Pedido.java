package es.indra.models;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data   // getter, setter, constructor completo, equals y hashcode, toString
@NoArgsConstructor   // Constructor por defecto
public class Pedido {
	
	private Producto producto;	
	private int cantidad;

}
