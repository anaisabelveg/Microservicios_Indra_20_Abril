package es.indra.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data   // getter, setter, constructor completo, equals y hashcode, toString
@NoArgsConstructor   // Constructor por defecto
@AllArgsConstructor
public class Producto {
	
	private Long ID;
	private String descripcion;
	private double precio;
	private Integer port;
	

}
